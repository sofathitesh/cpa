{include file="header.tpl.php"}


</div> <!-- End div wrapper in header.tpl -->



<div class="wrapper2">

<div class="h30"></div>

	<div class="title18">About Us</div>

	<div class="aboutBoxTop">

		<div class="pubBoxTopTitle">We are an online advertising agency</div>
		
		<ul class="pubTop">
		<li>We are an online advertising agency featuring numerous publisher tools including: <b>Content Lockers, Link Lockers, API Offers, Postback System and Real Time Tracking</b>.
		</li>

		<li><b>We have more than 1,000+ incent/non-incent offers</b> with top converting campaigns in a variety of niches. We have U.S. & International email submits, surveys, downloads, Mobile PIN/SMS campaigns that can monetize traffic from nearly any country.
		</li>

		<li>If you have traffic and are looking for a way to monetize it, don't look further. We are here to help. <b>Our support team is here to help 24/7</b>.
		</li>

		</ul>

	</div> <!-- End div pubBoxTop -->



</div> <!-- End div wrapper2 -->



<div class="h50"></div>

<div class="pubTitleBlue">Our Network Benefits</div>

<div class="h50"></div>



<div class="wrapper2">


	<div class="aboutBox">
		<div class="pubBoxTextTitle"><img src="{$SITE_URL}templates/images/img2/pub_i_payout.png" />Fast Payment (Paypal, Check, Wire). Net30</div>
		<div class="h30"></div>
		<div class="pubBoxTextTitle"><img src="{$SITE_URL}templates/images/img2/pub_i_postback.png" />Exclusive Tools: Content Locker & Link Locker</div>
		<div class="h30"></div>
		<div class="pubBoxTextTitle"><img src="{$SITE_URL}templates/images/img2/about_i_mobile.png" />Mobile-Friendly Platform</div>
		<div class="h30"></div>
	</div>

	<div class="aboutBetween"></div>

	<div class="aboutBox">
		<div class="pubBoxTextTitle"><img src="{$SITE_URL}templates/images/img2/about_i_offer.png" />Top Converting Offers from all around the world</div>
		<div class="h30"></div>
		<div class="pubBoxTextTitle"><img src="{$SITE_URL}templates/images/img2/about_i_postback.png" />API and Postback systems</div>
		<div class="h30"></div>
		<div class="pubBoxTextTitle"><img src="{$SITE_URL}templates/images/img2/about_i_referral.png" />Referral System so you can earn more</div>
		<div class="h30"></div>
	</div>


  
	



</div> <!-- End div wrapper2 -->



<div class="h40"></div>

<div class="wide_separator">&nbsp;</div>

<div class="h50"></div>

<center><a class="btnOrange" href="{$SITE_URL}register.php">Signup Today</a></center>

<div class="h40"></div>





{include file="footer.tpl.php"}

