</div>

<!--End Main Wrapper-->





<!--Footer-->

<div id="footer">



<!--Sub Footer-->

<div id="sub_footer">





<!--Section 1-->

<div class="section1">

<p class="footer_heading">About Us</p>

<p>CPA Network is a global Performance Marketing Network that provides content locking and monetization solutions for online publishers interested in maximizing their traffic's earnings.</p>

<p>» Powerful Tracking Platform</p>

<p>» Exclusive Publisher Tools</p>

<p>» 10% Referral Commissions</p>



<p>Join our community of happy publishers!</p>





</div>

<!--End Section - 1-->





<!--Section 2-->

<div class="section2">

<p class="footer_heading">Network</p>



<p>» <a href="{$SITE_URL}publishers.php">Publishers</a></p>

<p>» <a href="{$SITE_URL}about.php">Why Us?</a></p>

<p>» <a href="{$SITE_URL}terms.php">Terms Of Service</a></p>

<p>» <a href="{$SITE_URL}privacy.php">Privacy Policy</a></p>

<p>» <a href="{$SITE_URL}contact.php">Contact Us</a></p>









</div>

<!--End Section - 2-->





<!--Section 3-->

<div class="section2">

<p class="footer_heading">CPA Network</p>

<p>PO BOX 5342</p>

<p>Miami, FL 33212</p>

<br />

<img src="{$SITE_URL}templates/images/soso.png" alt="" />

</div>

<!--End Section - 3-->









</div>

<!--End Sub footer-->







<!--Footer Bottom-->

<div class="footer_bottom">



<div class="copyright">© 2009-2015 CPA network LLC. All Rights Reserved</div>



<div class="social_links">

<a href="#">f</a>&nbsp;<a href="#">t</a>

</div>



</div>

<!--End Footer Bootom-->







</div>

<!--End Footer-->



</body>

</html>

