<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<META HTTP-EQUIV="Refresh" CONTENT="5;URL={$url}">
<title>{$SITE_NAME} - Redirecting</title>
</head>

<body>
<center><h3>Please wait, you are being redirected</h3><br /><b>If it does not redirect you in 5 seconds, <a href="{$url}">click here</a>.
</b><br /><b>Thank you for using {$SITE_NAME}</b></center>
</body>
</html>