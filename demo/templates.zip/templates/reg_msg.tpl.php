{include file="header.tpl.php"}


<!--Page Contents Wrapper-->
<div class="page_contents_wrapper">



<div class="form_layout" style="width:740px; padding-top:75px;">
    <div class="alert alert-success">
    <br />
    
    <p>Dear <b>{$username}</b></p><br />
    <p>Thank you for registering with us. Please check your inbox for the email containing instruction to activate your account.</p>
    <p>Please check your spam folder if you do not see the email in your inbox.</p>

    
    <br />
     </div>

<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>
<div class="gap20px">&nbsp;</div>


</div>








</div>
<!--End Contents-->


{include file="footer.tpl.php"}