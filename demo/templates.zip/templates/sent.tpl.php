{include file="header.tpl.php"}


<!--Page Title and User earnings overview-->
<div id="page_header">

<div class="pageTitle">
Message Sent
</div>


<div class="liveCounters">

{include file="live_counters.tpl.php"}

</div>


</div>
<!--End Page Title and User eanrings overview-->

<!--Contents-->
<div id="content" >


<br />

<br />
<div>

Your message has been delivered to admin.<br /> <a href="messages.php" class="links">Back to Messages</a>

</div>







</div>
<!--End Contents-->


{include file="footer.tpl.php"}